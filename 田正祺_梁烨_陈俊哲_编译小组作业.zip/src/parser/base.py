from .myast import InternalNode, ExternalNode

