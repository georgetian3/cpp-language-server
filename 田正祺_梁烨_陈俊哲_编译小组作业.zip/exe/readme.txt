# C++ Lexer, Parser, and Text Editor

## Usage

Install dependencies:

```pip install -r requirements.txt```

Under the `src` folder, execute: `py main.py` to see usage help.